<?php

abstract class __custom_rees46
{
}
