<?php

new umiEventListener('order-status-changed', 'rees46', 'onOrderAdded');
new umiEventListener('order_refresh', 'rees46', 'onOrderRefresh');
