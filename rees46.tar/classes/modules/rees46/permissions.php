<?php
$permissions = array(
	'view' => array(
		'rees46', 'view', 'recommends', 'view_tpls', 'recommend_tpls','products_by_id'
	)
);
