<?php
$i18n = array(
	'module-rees46'            => 'REES46 connector',
	'module-rees46_dev'        => 'REES46 connector',
	'option-shop-id'           => 'Shop id',
	'header-rees46-config'     => 'REES46 Settings',
	'header-rees46_dev-config' => 'REES46 Settings',
	'perms-rees46-view'        => 'Perms view',
	'perms-rees46_dev-view'    => 'Perms view',
);
