<?php
$i18n = array(
	'module-rees46'            => 'REES46 коннектор',
	'module-rees46_dev'        => 'REES46 коннектор',
	'option-shop-id'           => 'Идентификатор магазина',
	'header-rees46-config'     => 'Настройки REES46',
	'header-rees46_dev-config' => 'Настройки REES46',
	'perms-rees46-view'        => 'Просмотр рекомендаций',
	'perms-rees46_dev-view'    => 'Просмотр рекомендаций',
);
