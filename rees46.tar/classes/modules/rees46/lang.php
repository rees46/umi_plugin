<?php
$C_LANG['module_name'] = 'REES46';
$C_LANG['module_title'] = 'rees46';

$C_LANG['events'] = 'rees46';

$LANG_EXPORT = array();
